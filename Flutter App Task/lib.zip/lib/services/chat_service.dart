import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/chat_message.dart';

class ChatService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<List<ChatMessage>> getMessages(String busId) {
    return _firestore
        .collection('chats')
        .doc(busId)
        .collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => ChatMessage.fromMap(doc.data())).toList());
  }

  Future<void> sendMessage(String busId, ChatMessage message) async {
    await _firestore
        .collection('chats')
        .doc(busId)
        .collection('messages')
        .add(message.toMap());
  }
}
