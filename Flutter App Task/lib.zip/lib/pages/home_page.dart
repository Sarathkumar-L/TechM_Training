import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../main.dart';
import 'my_localization.dart';
import 'bus_schedule_page.dart';
import 'map_page.dart';
import 'bus_tracking_page.dart';
import 'all_buses_page.dart';
import 'my_tickets_page.dart';
import 'login_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Locale _selectedLocale = Locale('en');
  final String? userEmail = FirebaseAuth.instance.currentUser?.email;

  void _changeLanguage(Locale locale) {
    setState(() {
      _selectedLocale = locale;
    });
    MyApp.setLocale(context, locale);
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => LoginPage()),
    );
  }

  Widget _buildFeatureCard(BuildContext context, IconData icon, String titleKey, Color color, VoidCallback onTap) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [color.withOpacity(0.7), color],
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 40,
                color: Colors.white,
              ),
              SizedBox(height: 10),
              Text(
                MyLocalizations.of(context).translate(titleKey),
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        title: Row(
          children: [
            Icon(Icons.directions_bus, size: 30),
            SizedBox(width: 10),
            Text(MyLocalizations.of(context).translate('home_title')),
          ],
        ),
        backgroundColor: Colors.green,
        actions: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Center(
              child: Text(
                userEmail ?? '',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: DropdownButton<Locale>(
              value: _selectedLocale,
              underline: Container(),
              icon: Icon(Icons.language, color: Colors.white),
              style: TextStyle(color: Colors.black, fontSize: 16),
              dropdownColor: Colors.white,
              onChanged: (Locale? newValue) {
                if (newValue != null) {
                  _changeLanguage(newValue);
                }
              },
              items: [
                DropdownMenuItem(
                  value: Locale('en'),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('English'),
                  ),
                ),
                DropdownMenuItem(
                  value: Locale('es'),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('Español'),
                  ),
                ),
                DropdownMenuItem(
                  value: Locale('ta'),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('தமிழ்'),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: TextButton.icon(
              icon: Icon(Icons.logout, color: Colors.white),
              label: Text(
                'Logout',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
              onPressed: _logout,
            ),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.green.shade100, Colors.white],
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            children: [
              Card(
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Row(
                    children: [
                      Icon(Icons.person, size: 40, color: Colors.green),
                      SizedBox(width: 10),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Welcome back,',
                            style: TextStyle(fontSize: 16),
                          ),
                          Text(
                            userEmail ?? '',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  children: [
                    _buildFeatureCard(
                      context,
                      Icons.search,
                      'search_bus',
                      Colors.blue,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => BusSearchPage()),
                      ),
                    ),
                    _buildFeatureCard(
                      context,
                      Icons.map,
                      'view_map',
                      Colors.green,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => MapPage()),
                      ),
                    ),
                    _buildFeatureCard(
                      context,
                      Icons.location_on,
                      'track_buses',
                      Colors.orange,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => BusTrackingPage()),
                      ),
                    ),
                    _buildFeatureCard(
                      context,
                      Icons.confirmation_number,
                      'book_ticket',
                      Colors.purple,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AllBusesPage()),
                      ),
                    ),
                    _buildFeatureCard(
                      context,
                      Icons.bookmark,
                      'my_tickets',
                      Colors.red,
                      () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => MyTicketsPage()),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}