import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class BusTrackingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Real-Time Bus Tracking')),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('busLocations').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

          List<Marker> markers = snapshot.data!.docs.map((doc) {
            double latitude = (doc['latitude'] as num).toDouble();
            double longitude = (doc['longitude'] as num).toDouble();
            String busId = doc['busId'];

            return Marker(
              width: 50.0,
              height: 50.0,
              point: LatLng(latitude, longitude),
              builder: (ctx) => GestureDetector(
                onTap: () {
                  showDialog(
                    context: ctx,
                    builder: (context) => AlertDialog(
                      title: Text('Bus Details'),
                      content: Text('Bus ID: $busId\nLocation: $latitude, $longitude'),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.of(context).pop(),
                          child: Text('Close'),
                        ),
                      ],
                    ),
                  );
                },
                child: Image.asset('assets/bus.png', width: 40, height: 40),
              ),
            );
          }).toList();

          return FlutterMap(
            options: MapOptions(
              center: LatLng(13.0481, 80.0945), // Default location (Panimalar Engineering College)
              zoom: 15.0,
            ),
            children: [
              TileLayer(
                urlTemplate: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                subdomains: ['a', 'b', 'c'],
              ),
              MarkerLayer(markers: markers),
            ],
          );
        },
      ),
    );
  }
}
