import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class BookingPage extends StatefulWidget {
  final String busId;
  final String routeId;
  final String time;

  BookingPage({required this.busId, required this.routeId, required this.time});

  @override
  _BookingPageState createState() => _BookingPageState();
}

class _BookingPageState extends State<BookingPage> {
  int _numberOfTickets = 1;
  double _ticketPrice = 0.0;
  double _totalPrice = 0.0;
  bool _isLoading = false;
  bool _isDataLoaded = false;
  String? _userId = FirebaseAuth.instance.currentUser?.uid;

  @override
  void initState() {
    super.initState();
    _fetchTicketPrice();
  }

  Future<void> _fetchTicketPrice() async {
    print("Fetching ticket price for busId: ${widget.busId}");

    try {
      // Querying Firestore to fetch the ticket price
      final querySnapshot = await FirebaseFirestore.instance
          .collection('busSchedules')
          .where('busId', isEqualTo: int.parse(widget.busId)) // Ensure busId is number
          .limit(1)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        final data = querySnapshot.docs.first.data();
        print("Bus Schedule Data: $data");

        setState(() {
          _ticketPrice = double.tryParse(data['ticketPrice'].toString()) ?? 0.0;
          _totalPrice = _ticketPrice * _numberOfTickets;
          _isDataLoaded = true;
        });
      } else {
        print("No document found for busId: ${widget.busId}");
        setState(() => _isDataLoaded = true);
      }
    } catch (e) {
      print('Error fetching ticket price: $e');
      setState(() => _isDataLoaded = true);
    }
  }

  void _updateTotalPrice() {
    setState(() {
      _totalPrice = _ticketPrice * _numberOfTickets;
    });
  }

  Future<void> _bookTickets() async {
    if (_userId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Please login to book tickets')),
      );
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Booking data
      DocumentReference bookingRef = await FirebaseFirestore.instance.collection('tickets').add({
        'userId': _userId,
        'busId': widget.busId,
        'routeId': widget.routeId,
        'numberOfTickets': _numberOfTickets,
        'ticketPrice': _ticketPrice,
        'totalPrice': _totalPrice,
        'bookingTime': FieldValue.serverTimestamp(),
        'status': 'confirmed',
        'time': widget.time,
      });

      // Save booking under user's document
      await FirebaseFirestore.instance
          .collection('users')
          .doc(_userId)
          .collection('bookings')
          .doc(bookingRef.id)
          .set({
        'bookingId': bookingRef.id,
        'busId': widget.busId,
        'routeId': widget.routeId,
        'numberOfTickets': _numberOfTickets,
        'totalPrice': _totalPrice,
        'bookingTime': FieldValue.serverTimestamp(),
        'status': 'confirmed',
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Tickets booked successfully!')),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error booking tickets: $e')),
      );
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Book Ticket')),
      body: _isDataLoaded
          ? SingleChildScrollView(
              padding: EdgeInsets.all(16.0),
              child: Card(
                elevation: 4,
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Booking Details',
                        style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                      ),
                      Divider(),
                      _buildInfoRow('Bus ID', widget.busId),
                      _buildInfoRow('Route ID', widget.routeId),
                      _buildInfoRow('Time', widget.time),
                      SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          IconButton(
                            icon: Icon(Icons.remove_circle_outline),
                            onPressed: () {
                              if (_numberOfTickets > 1) {
                                setState(() {
                                  _numberOfTickets--;
                                  _updateTotalPrice();
                                });
                              }
                            },
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 20),
                            child: Text(
                              '$_numberOfTickets',
                              style: TextStyle(fontSize: 24),
                            ),
                          ),
                          IconButton(
                            icon: Icon(Icons.add_circle_outline),
                            onPressed: () {
                              setState(() {
                                _numberOfTickets++;
                                _updateTotalPrice();
                              });
                            },
                          ),
                        ],
                      ),
                      Divider(),
                      _buildInfoRow('Ticket Price', '\$${_ticketPrice.toStringAsFixed(2)}'),
                      _buildInfoRow('Total Amount', '\$${_totalPrice.toStringAsFixed(2)}'),
                      SizedBox(height: 20),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          onPressed: _isLoading ? null : _bookTickets,
                          style: ElevatedButton.styleFrom(padding: EdgeInsets.symmetric(vertical: 15)),
                          child: _isLoading
                              ? CircularProgressIndicator(color: Colors.white)
                              : Text('Confirm Booking'),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            )
          : Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Loading booking details...', style: TextStyle(fontSize: 16)),
                ],
              ),
            ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 16, color: Colors.grey[600]),
          ),
          Text(
            value,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}
