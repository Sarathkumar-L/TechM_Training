import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class RouteManagement extends StatelessWidget {
  final TextEditingController _routeIdController = TextEditingController();
  final TextEditingController _sourceController = TextEditingController();
  final TextEditingController _destinationController = TextEditingController();

  Future<void> _addRoute() async {
    if (_routeIdController.text.isNotEmpty && _sourceController.text.isNotEmpty && _destinationController.text.isNotEmpty) {
      await FirebaseFirestore.instance.collection('routes').add({
        'routeId': _routeIdController.text,
        'source': _sourceController.text,
        'destination': _destinationController.text,
      });
      _routeIdController.clear();
      _sourceController.clear();
      _destinationController.clear();
    }
  }

  Future<void> _deleteRoute(String id) async {
    await FirebaseFirestore.instance.collection('routes').doc(id).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Routes'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _routeIdController,
              decoration: InputDecoration(labelText: 'Route ID'),
            ),
            TextField(
              controller: _sourceController,
              decoration: InputDecoration(labelText: 'Source'),
            ),
            TextField(
              controller: _destinationController,
              decoration: InputDecoration(labelText: 'Destination'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addRoute,
              child: Text('Add Route'),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('routes').snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return CircularProgressIndicator();
                  return ListView(
                    children: snapshot.data!.docs.map((doc) {
                      return ListTile(
                        title: Text('Route: ${doc['routeId']}'),
                        subtitle: Text('${doc['source']} to ${doc['destination']}'),
                        trailing: IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () => _deleteRoute(doc.id),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}