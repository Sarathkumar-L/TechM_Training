import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SetTicketPricePage extends StatelessWidget {
  final TextEditingController _priceController = TextEditingController();

  Future<void> _setPrice(BuildContext context, String busId, String routeId) async {
    try {
      double price = double.tryParse(_priceController.text) ?? 0.0;
      
      // Update price in busSchedules collection
      await FirebaseFirestore.instance.collection('busSchedules').doc(busId).update({
        'ticketPrice': price,
        'lastUpdated': FieldValue.serverTimestamp(),
      });

      // Store price history for tracking
      await FirebaseFirestore.instance.collection('priceHistory').add({
        'busId': busId,
        'routeId': routeId,
        'price': price,
        'timestamp': FieldValue.serverTimestamp(),
      });

      _priceController.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Price updated successfully!')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error updating price: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Set Ticket Prices'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('busSchedules').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          
          return ListView(
            padding: EdgeInsets.all(16),
            children: snapshot.data!.docs.map((doc) {
              Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
              double ticketPrice = data.containsKey('ticketPrice') ? data['ticketPrice'] : 0.0;
              
              return Card(
                elevation: 4,
                margin: EdgeInsets.only(bottom: 16),
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Bus: ${data['busId']}',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            icon: Icon(Icons.edit, color: Colors.blue),
                            onPressed: () {
                              showDialog(
                                context: context,
                                builder: (context) => AlertDialog(
                                  title: Text('Set Price for Bus ${data['busId']}'),
                                  content: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      TextField(
                                        controller: _priceController,
                                        keyboardType: TextInputType.number,
                                        decoration: InputDecoration(
                                          labelText: 'Enter new price',
                                          prefixText: '\$',
                                          border: OutlineInputBorder(),
                                        ),
                                      ),
                                      SizedBox(height: 10),
                                      Text(
                                        'Current Price: \$${ticketPrice.toStringAsFixed(2)}',
                                        style: TextStyle(
                                          color: Colors.grey[600],
                                          fontSize: 14,
                                        ),
                                      ),
                                    ],
                                  ),
                                  actions: [
                                    TextButton(
                                      onPressed: () => Navigator.of(context).pop(),
                                      child: Text('Cancel'),
                                    ),
                                    ElevatedButton(
                                      onPressed: () {
                                        _setPrice(context, doc.id, data['routeId']);
                                        Navigator.of(context).pop();
                                      },
                                      child: Text('Set Price'),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Route: ${data['routeId']}',
                        style: TextStyle(fontSize: 16),
                      ),
                      SizedBox(height: 8),
                      Text(
                        'Current Price: \$${ticketPrice.toStringAsFixed(2)}',
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.green,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      if (data.containsKey('lastUpdated'))
                        Text(
                          'Last Updated: ${(data['lastUpdated'] as Timestamp).toDate().toString()}',
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                    ],
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}