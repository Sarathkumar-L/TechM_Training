// admin_panel.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'bus_schedule_management.dart';
import 'route_management.dart';
import 'admin_bookings_page.dart';
import 'set_ticket_price_page.dart';
import 'my_localization.dart';
import 'login_page.dart';
import '../main.dart';

class AdminPanel extends StatefulWidget {
  @override
  _AdminPanelState createState() => _AdminPanelState();
}

class _AdminPanelState extends State<AdminPanel> {
  Locale _selectedLocale = Locale('en');
  final String? userEmail = FirebaseAuth.instance.currentUser?.email;

  void _changeLanguage(Locale locale) {
    setState(() {
      _selectedLocale = locale;
    });
    MyApp.setLocale(context, locale);
  }

  void _logout() async {
    await FirebaseAuth.instance.signOut();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (context) => LoginPage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Expanded(
              child: Text(
                MyLocalizations.of(context).translate('admin_panel'),
                style: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
        backgroundColor: Colors.blue,
        toolbarHeight: 70,
        actions: [
          // User Email
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: Center(
              child: Text(
                userEmail ?? '',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          // Language Dropdown
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: DropdownButton<Locale>(
              value: _selectedLocale,
              underline: Container(),
              icon: Icon(Icons.language, color: Colors.white),
              style: TextStyle(color: Colors.black, fontSize: 16),
              dropdownColor: Colors.white,
              onChanged: (Locale? newValue) {
                if (newValue != null) {
                  _changeLanguage(newValue);
                }
              },
              items: [
                DropdownMenuItem(
                  value: Locale('en'),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('English'),
                  ),
                ),
                DropdownMenuItem(
                  value: Locale('es'),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('Español'),
                  ),
                ),
                DropdownMenuItem(
                  value: Locale('ta'),
                  child: Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    child: Text('தமிழ்'),
                  ),
                ),
              ],
            ),
          ),
          // Logout Button
          Container(
            padding: EdgeInsets.symmetric(horizontal: 10),
            child: TextButton.icon(
              icon: Icon(Icons.logout, color: Colors.white),
              label: Text(
                'Logout',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
              onPressed: _logout,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => BusScheduleManagement()),
                );
              },
              child: Text(MyLocalizations.of(context).translate('manage_bus_schedules')),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => RouteManagement()),
                );
              },
              child: Text(MyLocalizations.of(context).translate('manage_routes')),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AdminBookingsPage()),
                );
              },
              child: Text(MyLocalizations.of(context).translate('current_bookings')),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SetTicketPricePage()),
                );
              },
              child: Text(MyLocalizations.of(context).translate('set_ticket_prices')),
            ),
          ],
        ),
      ),
    );
  }
}