// bus_schedule_page.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'booking_page.dart';

class BusSearchPage extends StatefulWidget {
  @override
  _BusSearchPageState createState() => _BusSearchPageState();
}

class _BusSearchPageState extends State<BusSearchPage> {
  String _searchQuery = '';
  String _selectedSource = 'All';
  String _selectedDestination = 'All';
  List<String> _sources = ['All'];
  List<String> _destinations = ['All'];

  @override
  void initState() {
    super.initState();
    _fetchSourcesAndDestinations();
  }

  Future<void> _fetchSourcesAndDestinations() async {
    final routesSnapshot = await FirebaseFirestore.instance.collection('routes').get();
    final sources = routesSnapshot.docs.map((doc) => doc['source'] as String).toSet().toList();
    final destinations = routesSnapshot.docs.map((doc) => doc['destination'] as String).toSet().toList();
    setState(() {
      _sources = ['All']..addAll(sources);
      _destinations = ['All']..addAll(destinations);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search Buses'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              decoration: InputDecoration(labelText: 'Search Destination'),
              onChanged: (value) {
                setState(() {
                  _searchQuery = value.toLowerCase();
                });
              },
            ),
            DropdownButton<String>(
              value: _selectedSource,
              onChanged: (value) {
                setState(() {
                  _selectedSource = value ?? 'All';
                });
              },
              items: _sources.map((source) {
                return DropdownMenuItem(
                  value: source,
                  child: Text(source),
                );
              }).toList(),
            ),
            DropdownButton<String>(
              value: _selectedDestination,
              onChanged: (value) {
                setState(() {
                  _selectedDestination = value ?? 'All';
                });
              },
              items: _destinations.map((destination) {
                return DropdownMenuItem(
                  value: destination,
                  child: Text(destination),
                );
              }).toList(),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('routes').snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return CircularProgressIndicator();
                  final filteredRoutes = snapshot.data!.docs.where((doc) {
                    final source = doc['source'].toString().toLowerCase();
                    final destination = doc['destination'].toString().toLowerCase();
                    return (_searchQuery.isEmpty || destination.contains(_searchQuery)) &&
                           (_selectedSource == 'All' || source == _selectedSource) &&
                           (_selectedDestination == 'All' || destination == _selectedDestination);
                  }).toList();

                  if (filteredRoutes.isEmpty) {
                    return Center(child: Text('No buses found'));
                  }

                  return ListView(
                    children: filteredRoutes.map((routeDoc) {
                      String routeId = routeDoc['routeId'].toString();

                      return ListTile(
                        title: Text('Route: $routeId'),
                        subtitle: Text('${routeDoc['source']} to ${routeDoc['destination']}'),
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => RouteBusSchedules(routeId: routeId),
                            ),
                          );
                        },
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class RouteBusSchedules extends StatelessWidget {
  final String routeId;

  RouteBusSchedules({required this.routeId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Buses for Route $routeId'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('busSchedules')
            .where('routeId', isEqualTo: routeId)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

          if (snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No buses available for this route.'));
          }

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              Timestamp timestamp = doc['time'];
              DateTime dateTime = timestamp.toDate();
              String formattedTime = "${dateTime.hour}:${dateTime.minute}";

              return ListTile(
                title: Text('Bus: ${doc['busId']}'),
                subtitle: Text('Time: $formattedTime'),
                trailing: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BookingPage(
                          busId: doc['busId'],
                          routeId: routeId,
                          time: formattedTime,
                        ),
                      ),
                    );
                  },
                  child: Text('Book'),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}