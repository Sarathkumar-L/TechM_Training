// all_buses_page.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'booking_page.dart';

class AllBusesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Buses'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('busSchedules').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
          return ListView(
            children: snapshot.data!.docs.map((doc) {
              Timestamp timestamp = doc['time'];
              DateTime dateTime = timestamp.toDate();
              String formattedTime = "${dateTime.hour}:${dateTime.minute}";

              // Convert busId and routeId to strings if they are integers
              String busId = doc['busId'].toString();
              String routeId = doc['routeId'].toString();

              return ListTile(
                title: Text('Bus: $busId'),
                subtitle: Text('Route: $routeId at $formattedTime'),
                trailing: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => BookingPage(
                          busId: busId,
                          routeId: routeId,
                          time: formattedTime,
                        ),
                      ),
                    );
                  },
                  child: Text('Book'),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}