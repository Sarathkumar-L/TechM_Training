import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class BusScheduleManagement extends StatelessWidget {
  final TextEditingController _routeIdController = TextEditingController();
  final TextEditingController _busIdController = TextEditingController();
  final TextEditingController _timeController = TextEditingController();

  Future<void> _addSchedule() async {
    if (_routeIdController.text.isNotEmpty && _busIdController.text.isNotEmpty && _timeController.text.isNotEmpty) {
      DateTime? dateTime = DateTime.tryParse(_timeController.text);
      if (dateTime != null) {
        await FirebaseFirestore.instance.collection('busSchedules').add({
          'routeId': _routeIdController.text,
          'busId': _busIdController.text,
          'time': Timestamp.fromDate(dateTime),
        });
        _routeIdController.clear();
        _busIdController.clear();
        _timeController.clear();
      } else {
        print('Invalid time format');
      }
    }
  }

  Future<void> _deleteSchedule(String id) async {
    await FirebaseFirestore.instance.collection('busSchedules').doc(id).delete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manage Bus Schedules'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _routeIdController,
              decoration: InputDecoration(labelText: 'Route ID'),
            ),
            TextField(
              controller: _busIdController,
              decoration: InputDecoration(labelText: 'Bus ID'),
            ),
            TextField(
              controller: _timeController,
              decoration: InputDecoration(labelText: 'Time (e.g., 2023-10-10 08:00:00)'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _addSchedule,
              child: Text('Add Schedule'),
            ),
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('busSchedules').snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) return CircularProgressIndicator();
                  return ListView(
                    children: snapshot.data!.docs.map((doc) {
                      Timestamp timestamp = doc['time'];
                      DateTime dateTime = timestamp.toDate();
                      String formattedTime = "${dateTime.hour}:${dateTime.minute}";

                      return ListTile(
                        title: Text('Bus: ${doc['busId']}'),
                        subtitle: Text('Route: ${doc['routeId']} at $formattedTime'),
                        trailing: IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () => _deleteSchedule(doc.id),
                        ),
                      );
                    }).toList(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}