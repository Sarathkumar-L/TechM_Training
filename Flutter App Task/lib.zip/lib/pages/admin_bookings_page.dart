// admin_bookings_page.dart
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminBookingsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Current Bookings'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('tickets').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

          // Ensure numberOfTickets is accessed correctly and summed
          int totalTickets = snapshot.data!.docs.fold(0, (sum, doc) {
            return sum + (doc['numberOfTickets'] as int);
          });

          return Column(
            children: [
              Text('Total Tickets Booked: $totalTickets', style: TextStyle(fontSize: 18)),
              Expanded(
                child: ListView(
                  children: snapshot.data!.docs.map((doc) {
                    return ListTile(
                      title: Text('Bus: ${doc['busId']}'),
                      subtitle: Text('Route: ${doc['routeId']} - ${doc['numberOfTickets']} tickets'),
                      trailing: Text('Total: \$${doc['totalPrice']}'),
                    );
                  }).toList(),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}