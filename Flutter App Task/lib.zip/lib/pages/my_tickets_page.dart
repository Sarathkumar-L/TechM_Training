import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class MyTicketsPage extends StatefulWidget {
  @override
  _MyTicketsPageState createState() => _MyTicketsPageState();
}

class _MyTicketsPageState extends State<MyTicketsPage> {
  final TextEditingController _messageController = TextEditingController();
  String userId = FirebaseAuth.instance.currentUser?.uid ?? '';
  String? selectedBusId;

  @override
  Widget build(BuildContext context) {
    if (userId.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: Text('My Tickets')),
        body: Center(child: Text('User not logged in')),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text('My Tickets')),
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('tickets')
                  .where('userId', isEqualTo: userId)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(child: CircularProgressIndicator());
                }

                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return Center(child: Text('No tickets found.'));
                }

                return ListView(
                  children: snapshot.data!.docs.map((doc) {
                    return ListTile(
                      title: Text('Bus: ${doc['busId']}'),
                      subtitle: Text(
                          'Route: ${doc['routeId']} - ${doc['numberOfTickets']} tickets'),
                      trailing: Text('Total: \$${doc['totalPrice']}'),
                      onTap: () {
                        setState(() {
                          selectedBusId = doc['busId'];
                        });
                      },
                    );
                  }).toList(),
                );
              },
            ),
          ),
          if (selectedBusId != null) _buildChatWindow(),
        ],
      ),
    );
  }

  /// **Chat Window Widget**
  Widget _buildChatWindow() {
    return Column(
      children: [
        Container(
          height: 250,
          decoration: BoxDecoration(
            border: Border(top: BorderSide(color: Colors.grey)),
            color: Colors.white,
          ),
          child: Column(
            children: [
              Expanded(
                child: StreamBuilder<QuerySnapshot>(
                  stream: FirebaseFirestore.instance
                      .collection('bus_chats')
                      .doc(selectedBusId)
                      .collection('messages')
                      .orderBy('timestamp', descending: true)
                      .snapshots(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    }

                    if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                      return Center(child: Text('No messages yet.'));
                    }

                    return ListView(
                      reverse: true,
                      children: snapshot.data!.docs.map((doc) {
                        return ListTile(
                          title: Text(doc['senderName']),
                          subtitle: Text(doc['message']),
                          trailing: Text(_formatTimestamp(doc['timestamp'])),
                        );
                      }).toList(),
                    );
                  },
                ),
              ),
              _buildMessageInput(),
            ],
          ),
        ),
      ],
    );
  }

  /// **Message Input Field**
  Widget _buildMessageInput() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _messageController,
              decoration: InputDecoration(
                hintText: 'Type a message...',
                border: OutlineInputBorder(),
              ),
            ),
          ),
          IconButton(
            icon: Icon(Icons.send),
            onPressed: _sendMessage,
          ),
        ],
      ),
    );
  }

  /// **Send Message Function**
void _sendMessage() async {
  if (_messageController.text.trim().isEmpty || selectedBusId == null) return;

  // Get user's name from Firestore
  DocumentSnapshot userDoc = await FirebaseFirestore.instance
      .collection('users')
      .doc(userId)
      .get();

  String senderName = userDoc.exists ? userDoc['name'] ?? 'Unknown' : 'Unknown';

  // Send message to Firestore
  await FirebaseFirestore.instance
      .collection('bus_chats')
      .doc(selectedBusId)
      .collection('messages')
      .add({
    'senderId': userId,
    'senderName': senderName,
    'message': _messageController.text.trim(),
    'timestamp': FieldValue.serverTimestamp(),
  });

  _messageController.clear();
}


  /// **Format Timestamp for Display**
  String _formatTimestamp(Timestamp? timestamp) {
    if (timestamp == null) return '';
    DateTime date = timestamp.toDate();
    return '${date.hour}:${date.minute.toString().padLeft(2, '0')}';
  }
}
