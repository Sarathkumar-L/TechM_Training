import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';
import 'package:firebase_auth/firebase_auth.dart';

class DriverPanel extends StatefulWidget {
  @override
  _DriverPanelState createState() => _DriverPanelState();
}

class _DriverPanelState extends State<DriverPanel> {
  String? busId;

  @override
  void initState() {
    super.initState();
    getAssignedBus();
    startTracking();
  }

  void getAssignedBus() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      DocumentSnapshot driverDoc = await FirebaseFirestore.instance
          .collection('drivers')
          .doc(user.uid)
          .get();
      
      if (driverDoc.exists) {
        setState(() {
          busId = driverDoc['busId'];
        });
      }
    }
  }

  void startTracking() async {
    Geolocator.getPositionStream(
      locationSettings: LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 5, // Update location every 5 meters
      ),
    ).listen((Position position) {
      if (busId != null) {
        FirebaseFirestore.instance.collection('busLocations').doc(busId).set({
          'latitude': position.latitude,
          'longitude': position.longitude,
          'timestamp': FieldValue.serverTimestamp(),
          'busId': busId
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Driver Panel')),
      body: Center(
        child: Text(busId != null
            ? 'Tracking Bus: $busId'
            : 'Fetching Bus ID...'),
      ),
    );
  }
}
